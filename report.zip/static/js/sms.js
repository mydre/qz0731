(function ($) {

	$(document).on('click', '.add_event', function (e) {
        //e.stopPropagation();
        var messageId = $(this).data('id');
		console.log(9);
        webview.slotJSEvent(messageId);
        return false;
    });
	
	$(document).on('click', '.add_event_key', function (e) {
        //e.stopPropagation();
        var messageId = $(this).data('key').toString();
		console.log(messageId);
        webview.slotJSStringEvent(messageId);
        return false;
    });

	//响应链接
    $(document).on('click', 'a', function (event) {
        event.preventDefault();
        var href = $(this).attr("href") || $(this).data("href");
		console.log(href);
        webview.slotHtmlEvent(href);
        return false;
    });
	
})(window.jQuery || jQuery);
