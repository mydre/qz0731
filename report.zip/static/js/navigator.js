(function ($) {

    var setting = {
        view: {
            dblClickExpand: false,
            showLine: false,
            selectedMulti: false,
            // 支持解析HTML字符串
			nameIsHTML: true
        },
        data: {
            key: {
                name: "d",
                url: "f",
                icon: "g",
                title: "c"
            },
            simpleData: {
                enable: true,
                idKey: "a",
                pIdKey: "b",
                rootPId: ""
            }
        },
        callback: {
            beforeClick: function(treeId, treeNode, clickFlag) {
                var zTree = $.fn.zTree.getZTreeObj("tree");
                var url = treeNode.f.split(".")[0];
                var pageNumber = url.substring(7);
                var frame = parent.frames["paginatorframe"];
                setTimeout(function(){
                    frame.postMessage(pageNumber, "*");
                },200);

                if (treeNode.isParent) {
                    zTree.expandNode(treeNode);
                    return true;
                } else {
                    return true;
                }
            },
			onClick: function () {}
        }
    };
    var sortBy = function (name) {
        return function (object1, object2) {
            var a;
            var b;

            if (object1 && object2 && typeof object1 === 'object' && typeof object2 === 'object') {
                a = object1[name];
                b = object2[name];
                if (a === b) {
                    return 0;
                }
                if (typeof a === typeof b) {
                    return a < b ? -1 : 1;
                }
                return typeof a < typeof b ? -1 : 1;
            } else {
                throw new Error("参数错误!");
            }
        }
    };
    // 构建菜单
    var buildTreeNode = function () {
        var znodes = data.list.sort(sortBy('a')),
            tree = $("#tree");

		for (var i = 0; i < znodes.length; i++) {
			znodes[i].target = "showframe";
		}

        tree = $.fn.zTree.init(tree, setting, znodes);
        tree.expandNode(tree.getNodeByParam('a', 2), true, false, false, false);
    };

    // 动态加载脚本
    var loadScript = function (url, callback) {
        var script = document.createElement("script"),
            head = document.getElementsByTagName("head")[0];

        script.type = "text/javascript";
        // IE
        if (script.readyState) {
            script.onreadystatechange = function () {
                if (script.readyState === "loaded" || script.readyState === "complete") {
                    script.onreadystatechange = null;
                    callback && callback();
                }
            }
        } else {
            // Chrome, Firefox等
            script.onload = function () {
                callback && callback();
            }
        }

        script.src = url;
        head.appendChild(script);
    };

    $(function () {
        var url = "data.js";

        loadScript(url, function () {
            buildTreeNode();
        });
    });

})(window.jQuery);