;(function ($, exports) {
    /**
     * Helper对象
     */
    var helper = {
        createFakeNode: function (text) {
            var fakeNode = document.createElement('span');
            fakeNode.style.cssText = 'position:absolute;left:-99999px;';
            fakeNode.textContent = text;
            return fakeNode;
        },
        copyNode: function (node) {
            var selection = document.getSelection();
            var isSuccess = false;
            selection.removeAllRanges();
            var range = document.createRange();
            range.selectNodeContents(node);
            selection.addRange(range);

            try {
                isSuccess = document.execCommand('copy');
                selection.removeAllRanges();
                return isSuccess;
            } catch (e) {
                throw new Error("无法复制");
            }
        },
        copyText: function (text) {
            var node = this.createFakeNode(text);
            var body = $('body');
            var isSuccess;

            body.append(node);
            isSuccess = this.copyNode(node);
            //body.remove(node);

            return isSuccess;
        }
    };

    /**
     * 复制到剪贴板功能
     * @param target 触发剪贴板对象
     * @param onSuccess 剪贴成功回调
     * @param onFailure 剪贴失败回调
     */
    var clipboard = function (target, onSuccess, onFailure) {
        var el = $(target);
        var targetText ;


        $('body').on('click', target,  function (e) {
            e.stopPropagation();
            targetText = $(this).data('copy');
            if (helper.copyText(targetText)) {
                $(this).text('复制成功');//.siblings('.js-btn-copy')
                onSuccess && onSuccess(targetText);
            } else {
                $(this).text('复制失败');
                onFailure && onFailure();
            }
        });

        return {
            destroy: function () {
                el.off('click');
            },
            el: el
        };
    };

    exports.clipboard = clipboard;
})(window.jQuery || jQuery, window);