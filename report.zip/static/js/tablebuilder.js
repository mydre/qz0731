var TableBuilder = (function () {
    var sortBy = function (name) {
        return function (object1, object2) {
            var a;
            var b;

            if (object1 && object2 && typeof object1 === 'object' && typeof object2 === 'object') {
                a = object1[name];
                b = object2[name];
                if (a === b) {
                    return 0;
                }
                if (typeof a === typeof b) {
                    return a < b ? -1 : 1;
                }
                return typeof a < typeof b ? -1 : 1;
            } else {
                throw new Error("参数错误!");
            }
        }
    };

    var TableBuilder = function (id) {
        this.id = id || "aux-navtree";
        this.space = "&nbsp;&nbsp;&nbsp;";

        this.init();
    };

    TableBuilder.prototype.init = function () {
        this.render();
    };

    TableBuilder.prototype.render = function () {
        var id = this.id,
            $tbody = $("#" + id),
            self = this,
            url = "data.js";

        var nodes = data.list.sort(sortBy('a'));
        var zNodesTree = self.buildTree(nodes, 0);
        var tpl = self.buildTableTemplate(zNodesTree);
        $tbody.append(tpl);

        self.setTableCellIndent($tbody, 3, 0);
        self.setTableCellIndent($tbody, 2, 0);
        self.setTableCellIndent($tbody, 1, 0);
        self.setTableCellIndent($tbody, 0, 0);

        self.mergeTableCellRowSpan($tbody, 0, 0);
        self.mergeTableCellRowSpan($tbody, 1, 0);
        self.mergeTableCellRowSpan($tbody, 2, 0);

        this.loadScript(url, function () {
            
        });
    };

    /**
     * 去除td中存在的&nbsp;字符
     * @param el tbody
     * @param tr tr在tbody中的索引
     * @param td td在tr中的索引
     */
    TableBuilder.prototype.setTableCellIndent = function (el, tr, td) {
        var cell = el.find("tr").eq(tr).find("td").eq(td);
        cell.html(cell.html().replace(/&nbsp;/g, ''));
        cell.css({
            "padding-left": "10px"
        });
    };

    /**
     * 合并单元格
     * @param el tbody
     * @param tr tr在tbody中的索引值
     * @param td td在tr中的索引值
     */
    TableBuilder.prototype.mergeTableCellRowSpan = function (el, tr, td) {
        var cell = el.find("tr").eq(tr).find("td").eq(td);
        cell.attr("colspan", 3).siblings("td").remove();
    };

    TableBuilder.prototype.buildTree = function (list, pId) {
        var ret = [];

        for (var key in list) {
            if (list.hasOwnProperty(key)) {
                if (list[key].b === pId) {
                    list[key].children = this.buildTree(list, list[key].a);
                    ret.push(list[key]);
                }
            }
        }
        return ret;
    };

    TableBuilder.prototype.buildTableTemplate = function (nodes) {
        var html = [],
            len = nodes.length,
            i = 0;

        for (; i < len; i++) {
            var currentNode = nodes[i];
			var page=0;
			var page=currentNode.f.split('.')[0].substr(7,currentNode.f.split('.')[0].length);
            if (currentNode.children.length) {
                html.push("<tr><td>" + this.space + "<img src='"+ currentNode.g +"'/>" +
                    "<a onclick=\"setPage("+page+")\" href='"+ currentNode.f +"' title='"+ currentNode.c +"'>" + currentNode.c +"</a></td>" +
                    "<td>"+ "(" + currentNode.e + ")" +"</td><td>"+ "(" + currentNode.e + ")" +"</td></tr>");
                this.space += "&nbsp;&nbsp;&nbsp;";
                html.push(this.buildTableTemplate(currentNode.children));
                // 3*6
                this.space = this.space.slice(0, this.space.length-18);
            } else {
                html.push("<tr><td>"+ this.space + "<img src='"+ currentNode.g +"'/>" +
                    "<a onclick=\"setPage("+page+")\" href='"+ currentNode.f +"' title='"+ currentNode.c +"'>" + currentNode.c +"</a></td>" +
                    "<td>"+ "(" +currentNode.e + ")" +"</td><td>"+ "(" +currentNode.e + ")" +"</td></tr>");
            }
        }
        return html.join("");
    };

    TableBuilder.prototype.loadScript = function (url, callback) {
        var script = document.createElement("script"),
            head = document.getElementsByTagName("head")[0];

        script.type = "text/javascript";

        if (script.readyState) {
            script.onreadystatechange = function () {
                if (script.readyState === "loaded" || script.readyState === "complete") {
                    script.onreadystatechange = null;
                    callback && callback();
                }
            }
        } else {
            script.onload = function () {
                callback && callback();
            }
        }

        script.src = url;
        head.appendChild(script);
    };

    return TableBuilder;
})();



//响应链接
    $(document).on('click', 'a', function (event) {
        var flag = true
        var href = $(this).attr("href");
		console.log( href);
        if(!href){
		  flag = false
		}
		return flag
    });